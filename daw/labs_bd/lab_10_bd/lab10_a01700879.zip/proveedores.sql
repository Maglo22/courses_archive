BULK INSERT a1700879.a1700879.[Proveedores]
FROM 'e:\wwwroot\a1700879\proveedores.csv'
WITH
(
	CODEPAGE='ACP',
	FIELDTERMINATOR=',',
	ROWTERMINATOR='\n'
)