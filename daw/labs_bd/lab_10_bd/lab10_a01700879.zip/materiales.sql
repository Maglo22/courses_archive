BULK INSERT a1700879.a1700879.[Materiales]
FROM 'e:\wwwroot\a1700879\materiales.csv'
WITH
(
	CODEPAGE='ACP',
	FIELDTERMINATOR=',',
	ROWTERMINATOR='\n'
)